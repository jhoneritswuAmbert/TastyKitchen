// All recipe data
const recipes = {
    1: {
        title: "Creamy Garlic Pasta",
        category: "Lunch & Dinner",
        image: "https://images.unsplash.com/photo-1676300184847-4ee4030409c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXN0YSUyMGRpc2glMjBmb29kfGVufDF8fHx8MTc2ODQwMTI1MHww&ixlib=rb-4.1.0&q=80&w=1080",
        description: "A rich and indulgent pasta dish that comes together in just 20 minutes. This creamy garlic pasta features al dente pasta tossed in a luscious sauce made with butter, cream, parmesan cheese, and plenty of aromatic garlic. Perfect for busy weeknights when you want something comforting and delicious!",
        prepTime: "5 minutes",
        cookTime: "15 minutes",
        servings: 4,
        difficulty: "Easy",
        rating: "4.8",
        ingredients: [
            "400g pasta (fettuccine or linguine)",
            "3 tablespoons butter",
            "6 cloves garlic, minced",
            "1 cup heavy cream",
            "1 cup grated Parmesan cheese",
            "Salt and black pepper to taste",
            "Fresh parsley, chopped (for garnish)",
            "Red pepper flakes (optional)"
        ],
        instructions: [
            {
                title: "Cook the Pasta",
                text: "Bring a large pot of salted water to a boil. Add the pasta and cook according to package directions until al dente (usually 8-10 minutes). Reserve 1 cup of pasta water before draining."
            },
            {
                title: "Prepare the Sauce",
                text: "While the pasta is cooking, melt butter in a large skillet over medium heat. Add the minced garlic and sauté for 1-2 minutes until fragrant, being careful not to burn it."
            },
            {
                title: "Add Cream",
                text: "Pour the heavy cream into the skillet with the garlic. Stir well and let it simmer for 2-3 minutes until it starts to thicken slightly."
            },
            {
                title: "Add Cheese",
                text: "Reduce heat to low and gradually add the grated Parmesan cheese, stirring constantly until the cheese is fully melted and the sauce is smooth. If the sauce is too thick, add a splash of the reserved pasta water."
            },
            {
                title: "Combine Pasta and Sauce",
                text: "Add the drained pasta to the skillet with the creamy garlic sauce. Toss everything together until the pasta is well coated. If needed, add more pasta water to achieve your desired consistency."
            },
            {
                title: "Season and Serve",
                text: "Season with salt and freshly ground black pepper to taste. Garnish with chopped fresh parsley and red pepper flakes if desired. Serve immediately while hot and enjoy!"
            }
        ],
        tips: [
            "Use fresh garlic: Fresh garlic makes a huge difference in flavor compared to pre-minced or garlic powder.",
            "Don't overcook the pasta: Cook it al dente since it will continue cooking slightly when mixed with the hot sauce.",
            "Save pasta water: The starchy pasta water helps create a silky sauce and helps it cling to the pasta better.",
            "Use quality Parmesan: Freshly grated Parmesan cheese melts better and tastes much better than pre-grated.",
            "Serve immediately: This pasta is best enjoyed fresh and hot, as the sauce can thicken as it cools."
        ],
        variations: [
            "Add protein: Top with grilled chicken, shrimp, or crispy bacon for a heartier meal.",
            "Make it lighter: Substitute half the cream with milk or use half-and-half instead of heavy cream.",
            "Add vegetables: Stir in baby spinach, sun-dried tomatoes, or roasted cherry tomatoes.",
            "Spice it up: Add red pepper flakes or a pinch of cayenne for some heat.",
            "Try different pasta: This sauce works great with penne, rigatoni, or spaghetti too!"
        ],
        nutrition: {
            calories: 520,
            protein: "18g",
            carbs: "62g",
            fat: "22g",
            fiber: "3g",
            sugar: "4g"
        }
    },
    2: {
        title: "Decadent Chocolate Cake",
        category: "Desserts",
        image: "https://images.unsplash.com/photo-1607257882338-70f7dd2ae344?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBjYWtlJTIwZGVzc2VydHxlbnwxfHx8fDE3Njg0NDQ2OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
        description: "An incredibly moist and rich chocolate cake that will satisfy any chocolate lover's cravings. This decadent dessert features multiple layers of tender chocolate cake covered in smooth, glossy chocolate ganache frosting. Perfect for birthdays, celebrations, or whenever you need a chocolate fix!",
        prepTime: "20 minutes",
        cookTime: "40 minutes",
        servings: 8,
        difficulty: "Medium",
        rating: "4.9",
        ingredients: [
            "2 cups all-purpose flour",
            "2 cups granulated sugar",
            "3/4 cup unsweetened cocoa powder",
            "2 teaspoons baking soda",
            "1 teaspoon baking powder",
            "1 teaspoon salt",
            "2 large eggs",
            "1 cup hot coffee",
            "1 cup buttermilk",
            "1/2 cup vegetable oil",
            "2 teaspoons vanilla extract",
            "For ganache: 2 cups chocolate chips, 1 cup heavy cream"
        ],
        instructions: [
            {
                title: "Preheat and Prepare",
                text: "Preheat your oven to 350°F (175°C). Grease and flour two 9-inch round cake pans or line them with parchment paper."
            },
            {
                title: "Mix Dry Ingredients",
                text: "In a large bowl, whisk together flour, sugar, cocoa powder, baking soda, baking powder, and salt until well combined."
            },
            {
                title: "Add Wet Ingredients",
                text: "Add eggs, coffee, buttermilk, oil, and vanilla extract to the dry ingredients. Beat with an electric mixer on medium speed for about 2 minutes until smooth. The batter will be thin."
            },
            {
                title: "Bake the Cakes",
                text: "Divide the batter evenly between the prepared pans. Bake for 30-40 minutes, or until a toothpick inserted in the center comes out clean. Cool in pans for 10 minutes, then remove to wire racks to cool completely."
            },
            {
                title: "Make the Ganache",
                text: "Heat heavy cream in a saucepan until it just begins to simmer. Pour over chocolate chips in a bowl and let sit for 2 minutes. Stir until smooth and glossy. Let cool until it reaches spreading consistency."
            },
            {
                title: "Assemble and Frost",
                text: "Place one cake layer on a serving plate. Spread a layer of ganache on top. Place the second layer on top and cover the entire cake with the remaining ganache. Refrigerate for 30 minutes before serving."
            }
        ],
        tips: [
            "Use hot coffee: It enhances the chocolate flavor without making the cake taste like coffee.",
            "Don't skip the buttermilk: It creates the perfect tender, moist texture.",
            "Cool completely: Make sure cakes are completely cool before frosting or the ganache will melt.",
            "Quality chocolate matters: Use good quality chocolate chips or chopped chocolate for the ganache.",
            "Make ahead: This cake tastes even better the next day after the flavors have melded."
        ],
        variations: [
            "Add layers: Make it a 3 or 4 layer cake for extra drama!",
            "Flavor the ganache: Add espresso powder, peppermint extract, or orange zest.",
            "Fill with raspberry: Spread raspberry jam between the layers for a fruity twist.",
            "Make cupcakes: Use the same batter to make about 24 cupcakes (bake for 18-22 minutes).",
            "White chocolate version: Use white chocolate chips in the ganache for a different flavor."
        ],
        nutrition: {
            calories: 580,
            protein: "8g",
            carbs: "78g",
            fat: "28g",
            fiber: "4g",
            sugar: "58g"
        }
    },
    3: {
        title: "Fresh Mediterranean Salad",
        category: "Healthy",
        image: "https://images.unsplash.com/photo-1620019989479-d52fcedd99fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHNhbGFkJTIwYm93bHxlbnwxfHx8fDE3NjgzODg3NjB8MA&ixlib=rb-4.1.0&q=80&w=1080",
        description: "A vibrant and refreshing Mediterranean salad packed with crisp vegetables, briny olives, and creamy feta cheese. Dressed with a simple lemon-herb vinaigrette, this healthy salad is perfect as a light lunch or as a side dish for grilled meats. It's colorful, nutritious, and bursting with fresh flavors!",
        prepTime: "15 minutes",
        cookTime: "0 minutes",
        servings: 2,
        difficulty: "Easy",
        rating: "4.7",
        ingredients: [
            "4 cups mixed greens or romaine lettuce",
            "1 cup cherry tomatoes, halved",
            "1 cucumber, diced",
            "1/2 red onion, thinly sliced",
            "1/2 cup Kalamata olives",
            "1/2 cup feta cheese, crumbled",
            "1/4 cup extra virgin olive oil",
            "2 tablespoons lemon juice",
            "1 teaspoon dried oregano",
            "Salt and pepper to taste"
        ],
        instructions: [
            {
                title: "Prepare the Vegetables",
                text: "Wash and dry all the vegetables thoroughly. Chop the lettuce into bite-sized pieces, halve the cherry tomatoes, dice the cucumber, and thinly slice the red onion."
            },
            {
                title: "Make the Dressing",
                text: "In a small bowl, whisk together olive oil, lemon juice, oregano, salt, and pepper until well combined. Taste and adjust seasoning as needed."
            },
            {
                title: "Assemble the Salad",
                text: "In a large salad bowl, combine the lettuce, tomatoes, cucumber, red onion, and olives. Toss gently to mix."
            },
            {
                title: "Add Feta and Dress",
                text: "Sprinkle the crumbled feta cheese over the salad. Drizzle with the lemon-herb dressing just before serving."
            },
            {
                title: "Toss and Serve",
                text: "Gently toss the salad to coat everything with the dressing. Serve immediately while fresh and crisp. Enjoy!"
            }
        ],
        tips: [
            "Use fresh ingredients: The quality of your vegetables makes all the difference in this simple salad.",
            "Dress just before serving: Keep the salad crisp by adding the dressing right before eating.",
            "Quality olive oil: Use good extra virgin olive oil for the best flavor in the dressing.",
            "Customize the feta: Use more or less feta cheese depending on your preference.",
            "Make it a meal: Add grilled chicken, shrimp, or chickpeas for extra protein."
        ],
        variations: [
            "Add protein: Top with grilled chicken, salmon, or chickpeas for a complete meal.",
            "Different cheese: Try goat cheese or fresh mozzarella instead of feta.",
            "Add grains: Toss in cooked quinoa or couscous for more substance.",
            "Extra veggies: Add bell peppers, artichoke hearts, or roasted red peppers.",
            "Herb it up: Add fresh herbs like basil, parsley, or mint for extra freshness."
        ],
        nutrition: {
            calories: 320,
            protein: "9g",
            carbs: "18g",
            fat: "24g",
            fiber: "5g",
            sugar: "8g"
        }
    },
    4: {
        title: "Fluffy Buttermilk Pancakes",
        category: "Breakfast",
        image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=1080",
        description: "The perfect breakfast pancakes that are light, fluffy, and melt-in-your-mouth delicious. These buttermilk pancakes are easy to make and come out perfectly every time. Serve them with maple syrup, fresh berries, and butter for a classic breakfast treat that everyone will love!",
        prepTime: "10 minutes",
        cookTime: "15 minutes",
        servings: 4,
        difficulty: "Easy",
        rating: "4.9",
        ingredients: [
            "2 cups all-purpose flour",
            "2 tablespoons sugar",
            "2 teaspoons baking powder",
            "1 teaspoon baking soda",
            "1/2 teaspoon salt",
            "2 cups buttermilk",
            "2 large eggs",
            "1/4 cup melted butter",
            "1 teaspoon vanilla extract",
            "Butter for cooking"
        ],
        instructions: [
            {
                title: "Mix Dry Ingredients",
                text: "In a large bowl, whisk together flour, sugar, baking powder, baking soda, and salt."
            },
            {
                title: "Combine Wet Ingredients",
                text: "In another bowl, whisk together buttermilk, eggs, melted butter, and vanilla extract until well combined."
            },
            {
                title: "Make the Batter",
                text: "Pour the wet ingredients into the dry ingredients and stir gently until just combined. Don't overmix - a few lumps are okay! Let the batter rest for 5 minutes."
            },
            {
                title: "Heat the Griddle",
                text: "Heat a griddle or large skillet over medium heat. Add a small amount of butter and let it melt, coating the surface."
            },
            {
                title: "Cook the Pancakes",
                text: "Pour 1/4 cup of batter onto the griddle for each pancake. Cook until bubbles form on the surface and edges look set, about 2-3 minutes. Flip and cook for another 1-2 minutes until golden brown."
            },
            {
                title: "Serve Warm",
                text: "Stack the pancakes on a plate and serve immediately with butter, maple syrup, and your favorite toppings. Enjoy while hot!"
            }
        ],
        tips: [
            "Don't overmix: Lumpy batter makes fluffier pancakes. Overmixing develops gluten and makes them tough.",
            "Let batter rest: The 5-minute rest allows the baking powder to activate for extra fluffiness.",
            "Medium heat is key: Too hot and they'll burn outside while staying raw inside.",
            "Wait for bubbles: Flip only when you see bubbles forming and popping on the surface.",
            "Keep warm: Place cooked pancakes in a 200°F oven while you finish the batch."
        ],
        variations: [
            "Add blueberries: Fold in fresh or frozen blueberries into the batter.",
            "Chocolate chip: Add chocolate chips for a sweet treat.",
            "Banana walnut: Mash a banana into the batter and add chopped walnuts.",
            "Cinnamon spice: Add 1 teaspoon cinnamon and 1/4 teaspoon nutmeg.",
            "Whole wheat: Replace half the flour with whole wheat flour for added nutrition."
        ],
        nutrition: {
            calories: 380,
            protein: "12g",
            carbs: "54g",
            fat: "13g",
            fiber: "2g",
            sugar: "10g"
        }
    },
    5: {
        title: "Honey Glazed Salmon",
        category: "Lunch & Dinner",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=1080",
        description: "Perfectly cooked salmon fillets with a sweet and savory honey glaze. This restaurant-quality dish is surprisingly easy to make at home and ready in just 30 minutes. The glaze caramelizes beautifully, creating a delicious crust while keeping the salmon moist and tender inside.",
        prepTime: "10 minutes",
        cookTime: "20 minutes",
        servings: 4,
        difficulty: "Easy",
        rating: "4.8",
        ingredients: [
            "4 salmon fillets (6 oz each)",
            "3 tablespoons honey",
            "2 tablespoons soy sauce",
            "2 tablespoons lemon juice",
            "2 cloves garlic, minced",
            "1 tablespoon olive oil",
            "1/2 teaspoon black pepper",
            "Fresh parsley for garnish",
            "Lemon wedges for serving"
        ],
        instructions: [
            {
                title: "Prepare the Glaze",
                text: "In a small bowl, whisk together honey, soy sauce, lemon juice, minced garlic, and black pepper until well combined."
            },
            {
                title: "Prepare the Salmon",
                text: "Pat the salmon fillets dry with paper towels. This helps achieve a better sear and allows the glaze to stick better."
            },
            {
                title: "Sear the Salmon",
                text: "Heat olive oil in a large oven-safe skillet over medium-high heat. Place salmon fillets skin-side up and sear for 3-4 minutes until golden brown."
            },
            {
                title: "Flip and Glaze",
                text: "Carefully flip the salmon fillets. Brush generously with the honey glaze, reserving some for later."
            },
            {
                title: "Finish in Oven",
                text: "Transfer the skillet to a preheated 400°F oven. Bake for 8-10 minutes until the salmon is cooked through and flakes easily with a fork."
            },
            {
                title: "Garnish and Serve",
                text: "Remove from oven and brush with remaining glaze. Garnish with fresh parsley and serve with lemon wedges. Perfect with rice or vegetables!"
            }
        ],
        tips: [
            "Check for doneness: Salmon is done when it reaches 145°F internal temperature and flakes easily.",
            "Don't overcook: Salmon continues cooking after removed from heat, so take it out slightly before fully cooked.",
            "Quality matters: Use fresh, high-quality salmon for the best flavor and texture.",
            "Skin on or off: Both work! Skin helps hold the fillet together during cooking.",
            "Let it rest: Allow salmon to rest for 2-3 minutes before serving for juicier results."
        ],
        variations: [
            "Spicy version: Add sriracha or red pepper flakes to the glaze.",
            "Asian twist: Add ginger and sesame oil to the glaze.",
            "Maple glazed: Replace honey with maple syrup for different sweetness.",
            "Herb crusted: Add fresh dill or thyme to the glaze.",
            "Grilled version: Cook on a preheated grill instead of the oven."
        ],
        nutrition: {
            calories: 340,
            protein: "34g",
            carbs: "14g",
            fat: "16g",
            fiber: "0g",
            sugar: "12g"
        }
    }
};

// Get recipe ID from URL
function getRecipeIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id') || '1'; // Default to recipe 1 if no ID
}

// Load and display recipe
function loadRecipe() {
    const recipeId = getRecipeIdFromUrl();
    const recipe = recipes[recipeId];
    
    if (!recipe) {
        // Recipe not found, redirect to browse page
        window.location.href = 'browse.html';
        return;
    }
    
    // Update page title
    document.title = `${recipe.title} - Tasty Kitchen`;
    
    // Update hero image
    const heroImage = document.querySelector('.recipe-hero-image img');
    if (heroImage) {
        heroImage.src = recipe.image;
        heroImage.alt = recipe.title;
    }
    
    // Update breadcrumb
    const breadcrumbSpan = document.querySelector('.recipe-breadcrumb span');
    if (breadcrumbSpan) {
        breadcrumbSpan.textContent = recipe.title;
    }
    
    // Update title and description
    const titleElement = document.querySelector('.recipe-header h1');
    if (titleElement) {
        titleElement.textContent = recipe.title;
    }
    
    const descElement = document.querySelector('.recipe-description');
    if (descElement) {
        descElement.textContent = recipe.description;
    }
    
    // Update meta information
    updateMetaInfo(recipe);
    
    // Update ingredients
    updateIngredients(recipe.ingredients);
    
    // Update instructions
    updateInstructions(recipe.instructions);
    
    // Update tips
    updateTips(recipe.tips);
    
    // Update variations
    updateVariations(recipe.variations);
    
    // Update nutrition
    updateNutrition(recipe.nutrition);
}

function updateMetaInfo(recipe) {
    const metaItems = document.querySelectorAll('.meta-item');
    if (metaItems.length >= 5) {
        metaItems[0].querySelector('p').textContent = recipe.prepTime;
        metaItems[1].querySelector('p').textContent = recipe.cookTime;
        metaItems[2].querySelector('p').textContent = `${recipe.servings} people`;
        metaItems[3].querySelector('p').textContent = recipe.difficulty;
        metaItems[4].querySelector('p').textContent = `${recipe.rating} / 5.0`;
    }
}

function updateIngredients(ingredients) {
    const ingredientsList = document.querySelector('.ingredients-list');
    if (ingredientsList) {
        ingredientsList.innerHTML = ingredients.map((ingredient, index) => `
            <li>
                <input type="checkbox" id="ing${index + 1}">
                <label for="ing${index + 1}">${ingredient}</label>
            </li>
        `).join('');
    }
}

function updateInstructions(instructions) {
    const instructionsList = document.querySelector('.instructions-list');
    if (instructionsList) {
        instructionsList.innerHTML = instructions.map(step => `
            <li>
                <strong>${step.title}</strong>
                <p>${step.text}</p>
            </li>
        `).join('');
    }
}

function updateTips(tips) {
    const tipsCard = document.querySelector('.tips-card ul');
    if (tipsCard) {
        tipsCard.innerHTML = tips.map(tip => `<li>${tip}</li>`).join('');
    }
}

function updateVariations(variations) {
    const variationsCard = document.querySelector('.variations-card ul');
    if (variationsCard) {
        variationsCard.innerHTML = variations.map(variation => `<li>${variation}</li>`).join('');
    }
}

function updateNutrition(nutrition) {
    const nutritionItems = document.querySelectorAll('.nutrition-item');
    if (nutritionItems.length >= 6) {
        nutritionItems[0].querySelector('span').textContent = nutrition.calories;
        nutritionItems[1].querySelector('span').textContent = nutrition.protein;
        nutritionItems[2].querySelector('span').textContent = nutrition.carbs;
        nutritionItems[3].querySelector('span').textContent = nutrition.fat;
        nutritionItems[4].querySelector('span').textContent = nutrition.fiber;
        nutritionItems[5].querySelector('span').textContent = nutrition.sugar;
    }
}

// Adjust servings
let currentServings = 4;
let baseServings = 4;

function adjustServings(change) {
    const recipeId = getRecipeIdFromUrl();
    const recipe = recipes[recipeId];
    
    if (recipe) {
        baseServings = recipe.servings;
    }
    
    const newServings = currentServings + change;
    if (newServings < 1 || newServings > 20) return;
    
    currentServings = newServings;
    const servingsElement = document.getElementById('servingsCount');
    if (servingsElement) {
        servingsElement.textContent = currentServings;
    }
}

// Ingredient checkbox functionality
function setupIngredientCheckboxes() {
    const checkboxes = document.querySelectorAll('.ingredients-list input[type="checkbox"]');
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const label = this.nextElementSibling;
            if (this.checked) {
                label.style.textDecoration = 'line-through';
                label.style.opacity = '0.6';
            } else {
                label.style.textDecoration = 'none';
                label.style.opacity = '1';
            }
        });
    });
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadRecipe();
    
    // Re-setup checkbox listeners after content is loaded
    setTimeout(setupIngredientCheckboxes, 100);
});

// Print recipe function
function printRecipe() {
    window.print();
}

// Share recipe function
function shareRecipe() {
    if (navigator.share) {
        navigator.share({
            title: document.title,
            text: 'Check out this amazing recipe!',
            url: window.location.href
        }).catch(err => console.log('Error sharing:', err));
    } else {
        navigator.clipboard.writeText(window.location.href);
        alert('Recipe link copied to clipboard!');
    }
}

// Save recipe function
function saveRecipe() {
    alert('Recipe saved! (This would save to your account in a real application)');
}
